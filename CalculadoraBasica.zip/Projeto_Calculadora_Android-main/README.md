# Projeto_Calculadora_Android
Criação de um app que realiza operações básicas com 2 telas.
